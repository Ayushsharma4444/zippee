// import logo from './logo.svg';
// import './App.css';
import ResponsiveAppBar from './component/Navbar';
import Starwars from './component/Starwars';
function App() {
  return (
    <div className="App">
        <ResponsiveAppBar/>
        <Starwars/>
    </div>
  );
}

export default App;
